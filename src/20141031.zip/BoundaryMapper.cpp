#include "BoundaryMapper.h"

Boundary * BoundaryMapper::get_master()
{
	return this->master;
}

Boundary * BoundaryMapper::get_slave()
{
	return this->slave;
}

BoundingVolumeTree * BoundaryMapper::get_master_bvt()
{
	return this->master_bvt;
}


void BoundaryMapper::set_slave(Boundary * slave)
{
	this->slave = slave;
}

void BoundaryMapper::set_master(Boundary * master)
{
	this->master = master;
}

BoundaryMapper::~BoundaryMapper()
{
	if (master_bvt != NULL) {
		delete master_bvt;
	}
}

void BoundaryMapper::execute(std::vector<Mapping> * mapping)
{
	master->calculate_normals_and_supports();
	slave->calculate_normals_and_supports();
	master_bvt = master->compute_bounding_volume_tree();
	slave->find_closest_elements(master_bvt);
	slave->map_elements(mapping);
}
