/*
 * Assembler.h
 *
 *  Created on: Jun 12, 2013
 *      Author: olda
 */

#ifndef ASSEMBLER_H_
#define ASSEMBLER_H_

#include "SystemIncludes.h"
#include "Mapping.h"
#include "FEPrimalBase.h"
#include <math.h>


/**
 * object of Assembler class can assemble:
 * * the mortar matrices D and M
 */
class Assembler
{
public:
	Assembler();
	void assemble_d_m(
			std::vector<Mapping> *,
			Boundary * ,
			std::map<int,std::map<int,double> > &,
			std::map<int,std::map<int,double> > &);
	void assemble_supports_normals(
			Boundary * ,
			std::map<int,std::map<int,double> > &,
			std::map<int,std::map<int,double> > &);
	void assemble_l_d(
				std::vector<Mapping> *,
				Boundary * ,
				std::map<int,int> &,
				DenseMatrix<double> *,
				std::map<int,std::map<int,double> > &,
				std::map<int,std::map<int,double> > &,
				std::map<int,std::map<int,double> > &,
				std::map<int,std::map<int,double> > &,
				std::map<int,std::map<int,double> > &,
				std::map<int,std::map<int,double> > &);

private:
	double de[9*9];
	double me[9*9];
	FEPrimalBase fe_slave;
	FEPrimalBase fe_master;
};


#endif /* ASSEMBLER_H_ */
