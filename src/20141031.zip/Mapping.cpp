/*
 * Mapping.cpp
 *
 *  Created on: Mar 19, 2013
 *      Author: Oldřich Vlach
 */


#include "Mapping.h"

#ifndef ENSIGHT_GOLD_DOUBLE_WIDTH
#define ENSIGHT_GOLD_DOUBLE_WIDTH 12
#endif
#ifndef ENSIGHT_GOLD_INT_WIDTH
#define ENSIGHT_GOLD_INT_WIDTH 10
#endif

Mapping::Mapping(Element * el_slave)
{
	element_slave = el_slave;
	element_coverage_area_ratio = 0.0;
}

void Mapping::add_segments_for_master(Element * master_el, const std::vector<MCVec2> & slave, const std::vector<MCVec2> & master)
{
	Triangle tri;
	tri.m[0] = master[0];  tri.m[1] = master[1];  tri.m[2] = master[2];
	tri.s[0] =  slave[0];  tri.s[1] =  slave[1];  tri.s[2] =  slave[2];
	if (segments_for_master.count(master_el->get_id()) < 1)
	{
		segments_for_master.insert(std::pair<int, std::vector<Triangle> >(master_el->get_id(), std::vector<Triangle>()));
	}
	segments_for_master[master_el->get_id()].push_back(tri);
}
//void Mapping::add_trinagle(const std::vector<MCVec2> & slave, const std::vector<MCVec2> & master)
//{
//	Triangle tri;
//	tri.m[0] = master[0];  tri.m[1] = master[1];  tri.m[2] = master[2];
//	tri.s[0] =  slave[0];  tri.s[1] =  slave[1];  tri.s[2] =  slave[2];
//	reference_coordinates.push_back(tri);
////	absolute_coordinates.push_back(absolute);
//}


int Mapping::write_ensight_gold( std::ofstream *geofile_ptr, int &node_counter, int &element_counter)
{
	if (geofile_ptr->is_open())
	{
		int tmp_int = 0;
		int tmp_int_counter=1;
		/* COORDINATES */
		(*geofile_ptr) << "coordinates\n";
		std::map<int, std::vector<Triangle> >::iterator sit_end = segments_for_master.end();
		for (std::map<int, std::vector<Triangle> >::iterator sit= segments_for_master.begin(); sit != sit_end; ++sit)
		{
			tmp_int += sit->second.size();
		}
		(*geofile_ptr) << std::setw( ENSIGHT_GOLD_INT_WIDTH) << 3*tmp_int << "\n";
		FEPrimalBase fe(1);
		for (int i=0; i<3*tmp_int; i++)
		{
			(*geofile_ptr) << std::setw( ENSIGHT_GOLD_INT_WIDTH) << node_counter++ << "\n";
		}
		std::vector<MCVec3> tmp_vector_mcvec3;
		for (std::map<int, std::vector<Triangle> >::iterator sit= segments_for_master.begin(); sit != sit_end; ++sit)
		{
			for (unsigned int i=0; i < sit->second.size(); i++)
			{
				std::vector<MCVec2> tmp_vector_mcvec2;
				tmp_vector_mcvec2.push_back(MCVec2(sit->second[i].s[0]));
				tmp_vector_mcvec2.push_back(MCVec2(sit->second[i].s[1]));
				tmp_vector_mcvec2.push_back(MCVec2(sit->second[i].s[2]));
				fe.init_all(element_slave,&tmp_vector_mcvec2);
				const std::vector<MCVec3> tmp_mcvec3 = fe.get_refpoints_coordiantes(&tmp_vector_mcvec2);
				tmp_vector_mcvec3.push_back(tmp_mcvec3[0]);
				tmp_vector_mcvec3.push_back(tmp_mcvec3[1]);
				tmp_vector_mcvec3.push_back(tmp_mcvec3[2]);
			}
		}
		std::vector<MCVec3>::iterator it_end = tmp_vector_mcvec3.end();
		for (std::vector<MCVec3>::iterator it = tmp_vector_mcvec3.begin(); it != it_end; ++it)
		{
			(*geofile_ptr) << std::setw( ENSIGHT_GOLD_DOUBLE_WIDTH) << it->x << "\n";
		}
		for (std::vector<MCVec3>::iterator it = tmp_vector_mcvec3.begin(); it != it_end; ++it)
		{
			(*geofile_ptr) << std::setw( ENSIGHT_GOLD_DOUBLE_WIDTH) << it->y << "\n";
		}
		for (std::vector<MCVec3>::iterator it = tmp_vector_mcvec3.begin(); it != it_end; ++it)
		{
			(*geofile_ptr) << std::setw( ENSIGHT_GOLD_DOUBLE_WIDTH) << it->z << "\n";
		}
		/* ELEMENTS */
		(*geofile_ptr) << "tria3\n";
		(*geofile_ptr) << std::setw( ENSIGHT_GOLD_INT_WIDTH) << tmp_int << "\n";
		for (int i=0; i<tmp_int; i++)
		{
			(*geofile_ptr) << std::setw( ENSIGHT_GOLD_INT_WIDTH) << element_counter++<< "\n";
		}
		for (int i=0; i<tmp_int; i++)
		{
			(*geofile_ptr)
					<< std::setw( ENSIGHT_GOLD_INT_WIDTH) << tmp_int_counter
					<< std::setw( ENSIGHT_GOLD_INT_WIDTH) << tmp_int_counter+1
					<< std::setw( ENSIGHT_GOLD_INT_WIDTH) << tmp_int_counter+2 << "\n";
			tmp_int_counter += 3;
		}
		return 1;
	}
	else
		return 0;
}




