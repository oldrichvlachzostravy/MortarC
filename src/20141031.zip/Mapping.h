
#ifndef MAPPING_H_
#define MAPPING_H_

#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>

class Mapping;

#include "SystemIncludes.h"
#include "MCVector.h"
#include "Element.h"

struct SegmentTriangle
{
	MCVec2 m[3];
	MCVec2 s[3];
};

struct SegmentLine
{
	double m[2];
	double s[2];
};

class Element;

class Mapping
{
	public:
		Mapping(Element *);
		void add_segments_for_master(Element *, const std::vector<MCVec2> &, const std::vector<MCVec2> &);
		Element * get_element_slave()  { return element_slave; };
		double get_element_coverage_area_ratio() {return element_coverage_area_ratio; };
		void add_to_element_coverage_area_ratio(double area) {element_coverage_area_ratio += area; };
		const std::map<int, std::vector<SegmentTriangle> > & get_segments_for_master() { return segments_for_master; };

		int write_ensight_gold( std::ofstream*, int&, int&);

	private:
		Element * element_slave;
		double element_coverage_area_ratio;
		std::map<int, std::vector<SegmentTriangle> > segments_for_master;
};


#endif /* MAPPING_H_ */
