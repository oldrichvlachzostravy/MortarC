#ifndef ELEMENT_H_
#define ELEMENT_H_
#include <map>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>

#include "SystemIncludes.h"
#include "MCVector.h"
#include "Utils.h"
#include "Boundary.h"
#include "Mapping.h"
// only temporalily
#include "mex.h"


class Node;
class Element;
class BoundingVolume;
class Boundary;

typedef std::list<MCVec3> PointList;
typedef std::map<int, Element*> ElementMap;
typedef std::map<int, PointList*> PolygonMap;

#define M_ELEMENT_LINE2 0
#define M_ELEMENT_LINE3 1
#define M_ELEMENT_TRIA3 2
#define M_ELEMENT_TRIA6 3
#define M_ELEMENT_QUAD4 4
#define M_ELEMENT_QUAD8 5
#define M_ELEMENT_QUAD9 6
#define M_ELEMENT_UNKNOWN 100

#define M_LINE2_NODES_COUNT 2
#define M_LINE3_NODES_COUNT 3
#define M_TRIA3_NODES_COUNT 3
#define M_TRIA6_NODES_COUNT 6
#define M_QUAD4_NODES_COUNT 4
#define M_QUAD8_NODES_COUNT 8

#define M_BOUND_COUNT_2D 4
#define M_BOUND_COUNT_3D 9

typedef int(*Compare)(const void *, const void *);
typedef double(*Value)(Node *);

#define M_LESSER 1
#define M_GREATER_OR_EQUAL 0

class Element_line2;

class Element
{
	public:
		virtual ~Element();
	    virtual double * get_shape_function_values(double, double) =0;
		virtual MCVec3 * get_jacobian(double, double) =0;
		virtual void calculate_normals_and_supports() =0;
		virtual MCVec3 * get_intersect(Element_line2*) =0;
		virtual MCVec3 * get_inner_point(Node*) =0;
		virtual bool is_point_inside(MCVec3) =0;
		virtual int get_type() const =0;
		virtual std::string get_type_name() const =0;
		virtual double get_support_weight_in_node(int) const =0;

		void calculate_centers_normal();
		void project_element_to_plane(double*);
		void mortar_segmentation(std::vector<Mapping> *);

		int get_id();
		Node * get_node(int);
		Node ** get_nodes();
		int get_node_count();
		Node * get_center();
		void set_bound_volume(BoundingVolume*);
		BoundingVolume * get_element_bounds();
		Interval get_element_bound(int);
		double get_distance();
		void set_distance(double);
		void set_closest_element(Element*, int);

		void set_divide_flag(bool);
		bool get_divide_flag();

		static Element * create_element(int, Node**, int);
		static int get_element_nodes_count(int);
		static int get_bound_count(int);
		static Value get_value_of_fn[9];
		static Compare compare_by_fn[9];

	protected:
		void compute_center();

		int id;
		Node** nodes;
		int node_count;
		Element **closest_elements;
		Node* center;
		double distance;
		BoundingVolume *element_bounds;
		bool divide_flag;
		int output_index;
		int input_index;

	private:
		void compute_projection_matrix(double*);

		enum CompareFncs {
			fn_x,
			fn_y,
			fn_y_minus_x,
			fn_y_plus_x,
			fn_z,
			fn_z_minus_x,
			fn_z_plus_x,
			fn_z_minux_y,
			fn_z_plus_y
		};

		static double get_value_of_fn_x(Node*);
		static double get_value_of_fn_y(Node*);
		static double get_value_of_fn_y_minus_x(Node*);
		static double get_value_of_fn_y_plus_x(Node*);
		static double get_value_of_fn_z(Node*);
		static double get_value_of_fn_z_minus_x(Node*);
		static double get_value_of_fn_z_plus_x(Node*);
		static double get_value_of_fn_z_minus_y(Node*);
		static double get_value_of_fn_z_plus_y(Node*);

		static int compare_by_fn_x(const void*, const void*);
		static int compare_by_fn_y(const void*, const void*);
		static int compare_by_fn_y_minus_x(const void*, const void*);
		static int compare_by_fn_y_plus_x(const void*, const void*);
		static int compare_by_fn_z(const void*, const void*);
		static int compare_by_fn_z_minus_x(const void*, const void*);
		static int compare_by_fn_z_plus_x(const void*, const void*);
		static int compare_by_fn_z_minus_y(const void*, const void*);
		static int compare_by_fn_z_plus_y(const void*, const void*);

};

/**
 * 1D line element with two nodes. Reference element is \f$ \langle-1,1 \rangle \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s) &=& \frac{1}{2}(1-s) \\
 *   N_2(s) &=& \frac{1}{2}(1+s)
 * \f}
 */
class Element_line2 : public Element
{
	public:
		Element_line2(int, Node**);
		virtual ~Element_line2() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

/**
 * 1D line element with three nodes. Reference element is \f$ \langle -1,1 \rangle \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s) &=& -\frac{1}{2}s(1-s) \\
 *   N_2(s) &=&  \frac{1}{2}s(1+s) \\
 *   N_3(s) &=&  (1-s)(1+s)
 * \f}
 */
class Element_line3 : public Element
{
	public:
		Element_line3(int id, Node**);
		virtual ~Element_line3() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

/**
 * 2D line element with three nodes. Reference element is \f$ (s,t)\in \langle 0,1 \rangle^2 :\ s+t\leq 1 \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s,t) &=& 1-(s+t) \\
 *   N_2(s,t) &=& s \\
 *   N_3(s,t) &=& t
 * \f}
 */
class Element_tria3: public Element
{
	public:
		Element_tria3(int, Node**);
		virtual ~Element_tria3() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

/**
 * 2D line element with three nodes. Reference element is \f$ (s,t)\in \langle 0,1 \rangle^2 :\ s+t\leq 1 \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s,t) &=& [1-(s+t)][1-2(s+t)] \\
 *   N_2(s,t) &=& s(2s-1) \\
 *   N_3(s,t) &=& t(2t-1) \\
 *   N_4(s,t) &=& s[1-(s+t)] \\
 *   N_5(s,t) &=& st \\
 *   N_6(s,t) &=& t[1-(s+t)]
 * \f}
 */
class Element_tria6: public Element
{
	public:
		Element_tria6(int, Node**);
		virtual ~Element_tria6() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

/**
 * 2D line element with three nodes. Reference element is \f$ (s,t)\in \langle 0,1 \rangle^2 \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s,t) &=& \frac{1}{4}(1-s)(1-t) \\
 *   N_2(s,t) &=& \frac{1}{4}(1+s)(1-t) \\
 *   N_3(s,t) &=& \frac{1}{4}(1+s)(1+t) \\
 *   N_4(s,t) &=& \frac{1}{4}(1-s)(1+t)
 * \f}
 */
class Element_quad4: public Element
{
	public:
		Element_quad4(int, Node**);
		virtual ~Element_quad4() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

/**
 * 2D line element with three nodes. Reference element is \f$ (s,t)\in \langle 0,1 \rangle^2 \f$
 * with shape functions
 * \f{eqnarray*}{
 *   N_1(s,t) &=& -\frac{1}{4}(1-s)(1-t)(1+s+t) \\
 *   N_2(s,t) &=& -\frac{1}{4}(1+s)(1-t)(1-s+t) \\
 *   N_3(s,t) &=& -\frac{1}{4}(1+s)(1+t)(1-s-t) \\
 *   N_4(s,t) &=& -\frac{1}{4}(1-s)(1+t)(1+s-t) \\
 *   N_5(s,t) &=&  \frac{1}{2}(1-s)(1+s)(1-t)   \\
 *   N_6(s,t) &=&  \frac{1}{2}(1+s)(1-t)(1+t)   \\
 *   N_7(s,t) &=&  \frac{1}{2}(1-s)(1+s)(1+t)   \\
 *   N_8(s,t) &=&  \frac{1}{2}(1-s)(1-t)(1+t)   \\
 * \f}
 */
class Element_quad8: public Element
{
	public:
		Element_quad8(int, Node**);
		virtual ~Element_quad8() { }

		double * get_shape_function_values(double, double);
		MCVec3 * get_jacobian(double, double);
		void calculate_normals_and_supports();
		MCVec3 * get_intersect(Element_line2*);
		bool is_point_inside(MCVec3);
		MCVec3 * get_inner_point(Node*);
		int get_type() const;
		std::string get_type_name() const;
		double get_support_weight_in_node(int) const;
};

#endif /* ELEMENT_H_ */
