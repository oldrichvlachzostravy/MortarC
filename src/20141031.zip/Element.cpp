#include "Element.h"
#include "Node.h"
#include "GaussianQuadrature.h"
//#include "Utils.h"

void Element::compute_center()
{
	MCVec3 c = MCVec3(0, 0, 0);
	for(int i = 0; i < this->node_count; i++) {
		c += this->nodes[i]->get_coordinates();
	}
	c /= this->node_count;
	this->center = new Node(-1, c);
}

void Element::set_bound_volume(BoundingVolume *bounds)
{
	this->element_bounds = bounds;
}

BoundingVolume * Element::get_element_bounds()
{
	return this->element_bounds;
}

Interval Element::get_element_bound(int bound_index)
{
	return this->element_bounds->get_bound(bound_index);
}

void Element::calculate_centers_normal()
{
	MCVec3 n;
	MCVec3 *j = this->get_jacobian(0, 0);
	switch (this->get_type())
	{
	case M_ELEMENT_LINE2:
	case M_ELEMENT_LINE3:
		n = MCVec2(-j->y,j->x); // rotate 90
		n.normalize();
		this->center->set_normal(n);
		break;
	case M_ELEMENT_TRIA3:
	case M_ELEMENT_TRIA6:
		n = cross_prod(j[0], j[1]);
		n.normalize();
		delete[] j;
		this->center->set_normal(n);
		break;
	default:                                            break;
	}
}

int Element::get_id()
{
	return this->id;
}

Node * Element::get_node(int i)
{
	return this->nodes[i];
}

Node ** Element::get_nodes()
{
	return this->nodes;
}

int Element::get_node_count()
{
	return this->node_count;
}

void Element::set_divide_flag(bool flag)
{
	this->divide_flag = flag;
}

bool Element::get_divide_flag()
{
	return this->divide_flag;
}

void Element::set_closest_element(Element *e, int index)
{
	this->closest_elements[index] = e;
}

void Element::mortar_segmentation(std::vector<Mapping> * mapping)
{
	double projection_matrix[12];
	compute_projection_matrix(projection_matrix);
	project_element_to_plane(projection_matrix);


	Element *e;
	ElementMap *incident_elms = new ElementMap();
	for (int i = 0; i < node_count; i++) {
		e = closest_elements[i];
		if (e != NULL) {
			e->project_element_to_plane(projection_matrix);
			// for each slave element node search for master elements belonging to
			incident_elms->insert(std::pair<int, Element*>(e->get_id(), e));
			// recursively enrich this set by neighboring master elements as much as possible (and correct)
			add_incident_elements(e, this, incident_elms, projection_matrix);
		}
	} // incident_elms now contains all needed master elements

	ElementMap::iterator it;
	PolygonMap *polygons = new PolygonMap();
	PointList *polygon;
	for(it = incident_elms->begin(); it != incident_elms->end(); it++)
	{
		polygon = clip_polygons(it->second, this);
		if(polygon->size() > 2)
		{
			polygons->insert(std::pair<int, PointList*>(it->first, polygon));
		}
		else
		{
			delete polygon;
		}
	}
	SegmentTriangle reference, absolute;
	MCVec3 u, v, w, t, tp;

	std::vector<TDescription*> triangles;
	PolygonMap::iterator pit;
	mapping->push_back(Mapping(this));
	// decompose all polygons to triangles
	for (pit = polygons->begin(); pit != polygons->end(); pit++) {
		e = incident_elms->at(pit->first);    // master element
		triangles = triangulate(pit->second);
		FEPrimalBase fe(1);
		std::vector<MCVec2> given_projected_nodes;
		for (uint j = 0; j < triangles.size(); j++) {
			absolute = SegmentTriangle();
			reference = SegmentTriangle();
			given_projected_nodes.resize(3);
			given_projected_nodes[0] = triangles[j]->p[0];
			given_projected_nodes[1] = triangles[j]->p[1];
			given_projected_nodes[2] = triangles[j]->p[2];
			const std::vector<MCVec2> result_slave  = fe.get_reference_coordinates(this,&given_projected_nodes);
			const std::vector<MCVec2> result_master = fe.get_reference_coordinates(e,&given_projected_nodes);

			// area of triangle ( see http://www.mathopenref.com/coordtrianglearea.html)
			double reference_element_area;
			switch (this->get_type())
			{
			case M_ELEMENT_LINE2:
			case M_ELEMENT_LINE3: reference_element_area = 2.0; break;
			case M_ELEMENT_TRIA3:
			case M_ELEMENT_TRIA6: reference_element_area = 0.5; break;
			case M_ELEMENT_QUAD4:
			case M_ELEMENT_QUAD8: reference_element_area = 4.0; break;
			default:              reference_element_area = 1.0; break;
			}
			double area = 0.5*fabs(
					result_slave[0].x*(result_slave[1].y-result_slave[2].y) +
					result_slave[1].x*(result_slave[2].y-result_slave[0].y) +
					result_slave[2].x*(result_slave[0].y-result_slave[1].y))/reference_element_area;
			mapping->rbegin()->add_to_element_coverage_area_ratio(area);
			mapping->rbegin()->add_segments_for_master(e, result_slave, result_master);
			delete triangles[j];
		}
	}

	delete incident_elms;
	for(pit = polygons->begin(); pit != polygons->end(); pit++) {
		delete pit->second;
	}
	delete polygons;
}

void Element::compute_projection_matrix(double *matrix)
{
	/**
	 *  See E. Sojka: Computer Graphics I - "skripta" http://mrl.cs.vsb.cz/people/sojka/pg/pocitacova_grafikaII.pdf
	 *  p. 22
	 */
	MCVec3 z = center->get_normal();
	MCVec3 x = MCVec3(1, 0, 0);
	MCVec3 y = MCVec3(0, 1, 0);
	MCVec3 t = center->get_coordinates();
	t.flip();
	if(z.x != 0 || z.y != 0) {
		x = MCVec3(-z.y, z.x, 0);
		x.normalize();
		y = cross_prod(z, x);
		y.normalize();
	}
	if(z.z == -1) {
		x = MCVec3(1, 0, 0);
		y = cross_prod(z, x);
		y.normalize();
	}

	matrix[0] = x.x;
	matrix[1] = y.x;
	matrix[2] = z.x;
	matrix[3] = x.y;
	matrix[4] = y.y;
	matrix[5] = z.y;
	matrix[6] = x.z;
	matrix[7] = y.z;
	matrix[8] = z.z;
	matrix[9] = dot_prod(x, t);
	matrix[10] = dot_prod(y, t);
	matrix[11] = dot_prod(z, t);
}

void Element::project_element_to_plane(double *projection_matrix)
{
	for(int i = 0; i < node_count; i++) {
		nodes[i]->project_point_to_plane(projection_matrix);
	}
}


Node * Element::get_center()
{
	return this->center;
}

double Element::get_distance()
{
	return this->distance;
}

void Element::set_distance(double distance)
{
	this->distance = distance;
}

Element::~Element() {
	delete[] nodes;
	if(center) {
		delete center;
	}
	delete[] closest_elements;
}

Element * Element::create_element(int id, Node **nodes, int element_type)
{
	if(element_type == M_ELEMENT_LINE2) {
		return new Element_line2(id, nodes);
	}
	if(element_type == M_ELEMENT_LINE3) {
		return new Element_line3(id, nodes);
	}
	if(element_type == M_ELEMENT_TRIA3) {
		return new Element_tria3(id, nodes);
	}
	if(element_type == M_ELEMENT_TRIA6) {
		return new Element_tria6(id, nodes);
	}
	if(element_type == M_ELEMENT_QUAD4) {
		return new Element_quad4(id, nodes);
	}
	if(element_type == M_ELEMENT_QUAD8) {
		return new Element_quad8(id, nodes);
	}

	return NULL;
}

int Element::get_element_nodes_count(int element_type)
{
	if(element_type == M_ELEMENT_LINE2) {
		return M_LINE2_NODES_COUNT;
	}
	if(element_type == M_ELEMENT_LINE3) {
		return M_LINE3_NODES_COUNT;
	}
	if(element_type == M_ELEMENT_TRIA3) {
		return M_TRIA3_NODES_COUNT;
	}
	if(element_type == M_ELEMENT_TRIA6) {
		return M_TRIA6_NODES_COUNT;
	}
	if(element_type == M_ELEMENT_QUAD4) {
		return M_QUAD4_NODES_COUNT;
	}
	if(element_type == M_ELEMENT_QUAD8) {
		return M_QUAD8_NODES_COUNT;
	}

	return 0;
}

int Element::get_bound_count(int element_type)
{
	if(element_type == M_ELEMENT_LINE2) {
		return M_BOUND_COUNT_2D;
	}
	if(element_type == M_ELEMENT_LINE3) {
		return M_BOUND_COUNT_2D;
	}
	if(element_type == M_ELEMENT_TRIA3) {
		return M_BOUND_COUNT_3D;
	}
	if(element_type == M_ELEMENT_TRIA6) {
		return M_BOUND_COUNT_3D;
	}
	if(element_type == M_ELEMENT_QUAD4) {
		return M_BOUND_COUNT_3D;
	}
	if(element_type == M_ELEMENT_QUAD8) {
		return M_BOUND_COUNT_3D;
	}

	return 0;
}

Value Element::get_value_of_fn[9] = {
		Element::get_value_of_fn_x,
		Element::get_value_of_fn_y,
		Element::get_value_of_fn_y_minus_x,
		Element::get_value_of_fn_y_plus_x,
		Element::get_value_of_fn_z,
		Element::get_value_of_fn_z_minus_x,
		Element::get_value_of_fn_z_plus_x,
		Element::get_value_of_fn_z_minus_y,
		Element::get_value_of_fn_z_plus_y
};

Compare	Element::compare_by_fn[9] = {
		Element::compare_by_fn_x,
		Element::compare_by_fn_y,
		Element::compare_by_fn_y_minus_x,
		Element::compare_by_fn_y_plus_x,
		Element::compare_by_fn_z,
		Element::compare_by_fn_z_minus_x,
		Element::compare_by_fn_z_plus_x,
		Element::compare_by_fn_z_minus_y,
		Element::compare_by_fn_z_plus_y
};

double Element::get_value_of_fn_x(Node *e)
{
	return e->get_coordinates().x;
}

double Element::get_value_of_fn_y(Node *e)
{
	return e->get_coordinates().y;
}

double Element::get_value_of_fn_y_minus_x(Node *e)
{
	return e->get_coordinates().y - e->get_coordinates().x;
}

double Element::get_value_of_fn_y_plus_x(Node *e)
{
	return e->get_coordinates().y + e->get_coordinates().x;
}

double Element::get_value_of_fn_z(Node *e)
{
	return e->get_coordinates().z;
}

double Element::get_value_of_fn_z_minus_x(Node *e)
{
	return e->get_coordinates().z - e->get_coordinates().x;
}

double Element::get_value_of_fn_z_plus_x(Node *e)
{
	return e->get_coordinates().z + e->get_coordinates().x;
}

double Element::get_value_of_fn_z_minus_y(Node *e)
{
	return e->get_coordinates().z - e->get_coordinates().y;
}

double Element::get_value_of_fn_z_plus_y(Node *e)
{
	return e->get_coordinates().z + e->get_coordinates().y;
}


/*
 * Compare two elements by function x
 */
int Element::compare_by_fn_x(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_x]((*e1)->get_center()) -
			get_value_of_fn[fn_x]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function y
 */
int Element::compare_by_fn_y(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_y]((*e1)->get_center()) -
			get_value_of_fn[fn_y]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function x = y
 */
int Element::compare_by_fn_y_minus_x(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_y_minus_x]((*e1)->get_center()) -
			get_value_of_fn[fn_y_minus_x]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function -x = y
 */
int Element::compare_by_fn_y_plus_x(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_y_plus_x]((*e1)->get_center()) -
			get_value_of_fn[fn_y_plus_x]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function z
 */
int Element::compare_by_fn_z(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_z]((*e1)->get_center()) -
			get_value_of_fn[fn_z]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function x = z
 */
int Element::compare_by_fn_z_minus_x(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_z_minus_x]((*e1)->get_center()) -
			get_value_of_fn[fn_z_minus_x]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function -x = z
 */
int Element::compare_by_fn_z_plus_x(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_z_plus_x]((*e1)->get_center()) -
			get_value_of_fn[fn_z_plus_x]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function z = y
 */
int Element::compare_by_fn_z_minus_y(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_z_minux_y]((*e1)->get_center()) -
			get_value_of_fn[fn_z_minux_y]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}

/*
 * Compare two elements by function z = -y
 */
int Element::compare_by_fn_z_plus_y(const void * element1, const void * element2)
{
	Element **e1 = (Element**)element1;
	Element **e2 = (Element**)element2;
	double d =
			get_value_of_fn[fn_z_plus_y]((*e1)->get_center()) -
			get_value_of_fn[fn_z_plus_y]((*e2)->get_center());
	if(d <= 0) {
		return -1;
	} else {
		return 1;
	}
}
