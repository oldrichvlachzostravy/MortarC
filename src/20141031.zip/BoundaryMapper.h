#ifndef BOUNDARYMAPPER_H_
#define BOUNDARYMAPPER_H_

#include <stdio.h>
#include <iostream>

class BoundaryMapper;

#include "SystemIncludes.h"
#include "Boundary.h"

#define MASTER 0
#define SLAVE 1


class BoundaryMapper
{
	public:
	    BoundaryMapper(): master(NULL), slave(NULL), master_bvt(NULL) {};
		~BoundaryMapper();

		void execute(std::vector<Mapping> *);
		void set_master(Boundary *);
		void set_slave(Boundary *);
		Boundary * get_master();
		Boundary * get_slave();
		BoundingVolumeTree * get_master_bvt();

	protected:
		Boundary *master, *slave;
		BoundingVolumeTree *master_bvt;
};

#endif /* BOUNDARYMAPPER_H_ */
