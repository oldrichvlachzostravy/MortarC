/*
 * Segment.h
 *
 *  Created on: Oct 24, 2014
 *      Author: olda
 */

#ifndef SEGMENT_H_
#define SEGMENT_H_


class Segment


#endif /* SEGMENT_H_ */
