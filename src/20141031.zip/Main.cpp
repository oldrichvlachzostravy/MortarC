#include <stdio.h>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <time.h>
#include <unistd.h>
#include <math.h>
//#include "mex.h"

#include "BoundaryMapper.h"
#include "Boundary.h"
#include "DenseMatrix.h"
#include "FEPrimalBase.h"
#include "Element.h"
#include "Assembler.h"

#define D3
#ifndef D3
#define D2
#endif

#define DEBUG_OUTPUTS         true

#ifndef ENSIGHT_GOLD_DOUBLE_WIDTH
#define ENSIGHT_GOLD_DOUBLE_WIDTH 12
#endif
#ifndef ENSIGHT_GOLD_INT_WIDTH
#define ENSIGHT_GOLD_INT_WIDTH 10
#endif

using namespace std;

DenseMatrix<double> *coordinates, *friction;
DenseMatrix<int> *domainN, *master_els, *nodes2dofs, *slave_els;
Boundary *master, *slave;
int element_type;

//int getElementType(DenseMatrix<int> *els)
//{
//	if((*els)[ 8*els->get_columns()+0]==0) return M_ELEMENT_LINE2;
//	if((*els)[ 9*els->get_columns()+0]==0) return M_ELEMENT_LINE3;
//	if((*els)[10*els->get_columns()+0]==0 && (*els)[ 8*els->get_columns()+0]==(*els)[ 9*els->get_columns()+0]) return M_ELEMENT_TRIA3;
//	if((*els)[10*els->get_columns()+0]==0) return M_ELEMENT_QUAD4;
//	if((*els)[13*els->get_columns()+0] >0 && (*els)[ 8*els->get_columns()+0]==(*els)[ 9*els->get_columns()+0]) return M_ELEMENT_TRIA6;
//	if((*els)[13*els->get_columns()+0] >0) return M_ELEMENT_QUAD8;
//
//	return -1;
//}

//void write_mapping(std::vector<Mapping> *mapping, Boundary * master, const char *fname, int ii)
//{
//	std::ostringstream tmp_ostringstream;
//	time_t rawtime;
//	struct tm * timeinfo;
//	tmp_ostringstream << fname << "/mapping_" << ii << ".txt";
//	time (&rawtime);
//	timeinfo = localtime(&rawtime);
//	std::ofstream out_file;
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "Mapping description (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n\n";
//		out_file << std::setiosflags(std::ios::right) << std::setprecision(5);
//		for (unsigned int i = 0; i < mapping->size(); i++)
//		{
//			out_file << "S:  " << mapping->at(i).get_element_slave()->get_id() << "   [";
//			for (int j = 0; j < mapping->at(i).get_element_slave()->get_node_count(); j++)
//			{
//				out_file << "  " << std::setw(4) << mapping->at(i).get_element_slave()->get_node(j)->get_id();
//			}
//			out_file << " ] -----------------------------------\n";
//			const std::map<int, std::vector<Triangle> > & segments_for_master = mapping->at(i).get_segments_for_master();
//			std::map<int, std::vector<Triangle> >::const_iterator it_end = segments_for_master.end();
//			for (std::map<int, std::vector<Triangle> >::const_iterator it = segments_for_master.begin(); it != it_end; ++it)
//			{
//				out_file << "  M:  " << it->first << "  [";
//				for (int j = 0; j < master->get_element(it->first)->get_node_count(); j++)
//				{
//					out_file << "  " << std::setw(4) << master->get_element(it->first)->get_node(j)->get_id();
//				}
//				out_file << " ]\n";
//				std::vector<Triangle>::const_iterator seg_it_end = it->second.end();
//				int counter=0;
//				for (std::vector<Triangle>::const_iterator seg_it = it->second.begin(); seg_it != seg_it_end; ++seg_it)
//				{
//					out_file << "    Tri:  " << ++counter << "      s[ ("
//							<< std::setw(7) << seg_it->s[0].x << ", "
//							<< std::setw(7) << seg_it->s[0].y << "), ("
//							<< std::setw(7) << seg_it->s[1].x << ", "
//							<< std::setw(7) << seg_it->s[1].y << "), ("
//							<< std::setw(7) << seg_it->s[2].x << ", "
//							<< std::setw(7) << seg_it->s[2].y << ")],   m[ ("
//							<< std::setw(7) << seg_it->m[0].x << ", "
//							<< std::setw(7) << seg_it->m[0].y << "), ("
//							<< std::setw(7) << seg_it->m[1].x << ", "
//							<< std::setw(7) << seg_it->m[1].y << "), ("
//							<< std::setw(7) << seg_it->m[2].x << ", "
//							<< std::setw(7) << seg_it->m[2].y << ")]\n";
//				}
//			}
//		}
//	}
//}

//void write_ensight_gold_slave_master_mapping(
//		BoundaryMapper &project, std::vector<Mapping> *mappings_ptr, const char *fname, int ii)
//{
//	std::ostringstream tmp_ostringstream;
//	time_t rawtime;
//	struct tm * timeinfo;
//	int part_counter = 1;
//	int node_counter = 1;
//	int element_counter = 1;
//    int tmp_int;
//	/* ENSIGHT .case FILE */
//	tmp_ostringstream << fname << "/contact_3d_mex_output_mapping_" << ii << ".case";
//	time (&rawtime);
//	timeinfo = localtime(&rawtime);
//	std::ofstream out_file;
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "# Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
//		out_file << "# EnSight Gold Model\n\n";
//		out_file << "FORMAT\n";
//		out_file << "type:                   ensight gold\n\n";
//		out_file << "GEOMETRY\n";
//		out_file << "model:                  contact_3d_mex_output_mapping_" << ii << ".geo\n\n";
//		out_file.close();
//	}
//	/* ENSIGHT .geo FILE */
//	tmp_ostringstream.str("");
//	tmp_ostringstream << fname << "/contact_3d_mex_output_mapping_" << ii << ".geo";
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
//		out_file << "Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
//		out_file << "node id given\n";
//		out_file << "element id given\n";
//		out_file << "extents\n";
//		out_file << std::setiosflags(std::ios::right | std::ios::scientific) << std::setprecision(5);
//		BoundingVolume * tmp_interval = project.get_master_bvt()->get_item();
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).end << "\n";
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).end << "\n";
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).end << "\n";
//		/* SLAVE */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		out_file << "slave\n";
//		project.get_slave()->write_ensight_gold(&out_file, node_counter, element_counter);
//		/* MASTER */
//		out_file << "part\n";
//		out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		out_file << "master\n";
//		project.get_master()->write_ensight_gold(&out_file, node_counter, element_counter);
//		/* MAPPING */
//		tmp_int = mappings_ptr->size();
//		for (int i=0; i<tmp_int; i++)
//		{
//			if (mappings_ptr->at(i).get_element_coverage_area_ratio() < MIN_SLAVE_COVER_RATIO) continue;
//			out_file << "part\n";
//			out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//			out_file << "mapping[" << i << "] (" << mappings_ptr->at(i).get_element_slave()->get_id() << ")\n";
//			mappings_ptr->at(i).write_ensight_gold(&out_file, node_counter, element_counter);
//		}
//	}
//	out_file.close();
//}

//void write_ensight_gold_normals(BoundaryMapper &project, std::vector<Mapping> *mappings_ptr, const char *fname, int ii)
//{
//	std::ostringstream tmp_ostringstream;
//	time_t rawtime;
//	struct tm * timeinfo;
//	int part_counter = 1;
//	int node_counter = 1;
//	int element_counter = 1;
//	/* ENSIGHT .case FILE */
//	std::ofstream out_file;
//	tmp_ostringstream << fname << "/contact_3d_mex_output_slave_master_" << ii << ".case";
//	time (&rawtime);
//	timeinfo = localtime(&rawtime);
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "# Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
//		out_file << "# EnSight Gold Model\n\n";
//		out_file << "FORMAT\n";
//		out_file << "type:                   ensight gold\n\n";
//		out_file << "GEOMETRY\n";
//		out_file << "model:                  contact_3d_mex_output_slave_master_" << ii << ".geo\n\n";
//		out_file << "VARIABLES\n";
//		out_file << "vector per node: 1 1 Normals contact_3d_mex__normals_" << ii << ".Nvec\n";
//		out_file << "scalar per node: 1 1 Supports contact_3d_mex__supports_" << ii << ".Nsca\n";
//		out_file.close();
//	}
//	/* ENSIGHT .geo FILE */
//	tmp_ostringstream.str("");
//	tmp_ostringstream << fname << "/contact_3d_mex_output_slave_master_" << ii << ".geo";
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
//		out_file << "Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
//		out_file << "node id given\n";
//		out_file << "element id given\n";
//		out_file << "extents\n";
//		out_file << std::setiosflags(std::ios::right | std::ios::scientific) << std::setprecision(5);
//		BoundingVolume * tmp_interval = project.get_master_bvt()->get_item();
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).end << "\n";
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).end << "\n";
//		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).start
//				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).end << "\n";
//		/* SLAVE */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		out_file << "slave\n";
//		project.get_slave()->write_ensight_gold(&out_file, node_counter, element_counter);
//		/* MASTER */
//		out_file << "part\n";
//		out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		out_file << "master\n";
//		project.get_master()->write_ensight_gold(&out_file, node_counter, element_counter);
//	}
//	out_file.close();
//	/* ENSIGHT contact_3d_mex__normals.Nvec FILE */
//	tmp_ostringstream.str("");
//	part_counter = 1;
//	tmp_ostringstream << fname << "/contact_3d_mex__normals_" << ii << ".Nvec";
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
//		/* SLAVE */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		project.get_slave()->write_normals_ensight_gold(&out_file);
//		/* MASTER */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		project.get_master()->write_normals_ensight_gold(&out_file);
//	}
//	out_file.close();
//	/* ENSIGHT contact_3d_mex__supports.Nsca FILE */
//	tmp_ostringstream.str("");
//	part_counter = 1;
//	tmp_ostringstream << fname << "/contact_3d_mex__supports_" << ii << ".Nsca";
//	out_file.open(tmp_ostringstream.str().c_str());
//	if (out_file.is_open())
//	{
//		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
//		/* SLAVE */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		project.get_slave()->write_supports_ensight_gold(&out_file);
//		/* MASTER */
//		out_file << "part\n";
//		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
//		project.get_master()->write_supports_ensight_gold(&out_file);
//	}
//	out_file.close();
//}

template <typename T> DenseMatrix<T> * load_matlab_ascii_matrix(const char* fileName)
{
	string str;
	ifstream myfile(fileName);

	if (myfile.is_open()) {
		getline(myfile, str);
		int rows, columns;
		if (sscanf(str.c_str(), "%d %d", &rows, &columns) != 2) {
			myfile.close();
			return NULL;
		}

		DenseMatrix<T> *result = new DenseMatrix<T>(rows, columns);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				if (!myfile.good()) {
					delete result;
					return NULL;
				}
				//getline(myfile, str, ' ');
				//stringstream ss(str.c_str());
				myfile >> (*result)[i * columns + j];
			}
		}
		myfile.close();
		return result;
	} else {
		return NULL;
	}
}

int main(int argc, char** argv)
{
	int i, tmpint1, tmpint2;
	double *master_els_ptr, *slave_els_ptr, *coordinates0_ptr, *friction_ptr;

	string path = "/home/olda/workspace/MortarC/matrix/test2d/";
	string example_root = "/home/olda/workspace/MortarC/matrix/test2d/";
	string problem_name = "herz2d";
	char const_string_options[]      = "options";
	char const_string_general[]      = "general";
	char const_string_problem_name[] = "problem_name";
	char const_string_example_root[] = "example_root";

	DenseMatrix<double> *friction, *coordinates;
	DenseMatrix<int> *master_els, *slave_els;
	Boundary *master, *slave;
	int master_els_type, slave_els_type;

	/* ******** */
	/* * INIT * */
	/* ******** */
	coordinates = load_matlab_ascii_matrix<double>((path + "coordinates.ascii").c_str());
	if(!coordinates)
	{
		fprintf(stderr, "Can not load coordinate matrix\n");
		exit(1);
	}
	master_els = load_matlab_ascii_matrix<int>((path + "master_els.ascii").c_str());
	if(!master_els) {
		fprintf(stderr, "Can not load master elements matrix\n");
		exit(1);
	}
	slave_els = load_matlab_ascii_matrix<int>((path + "slave_els.ascii").c_str());
	if(!slave_els) {
		fprintf(stderr, "Can not load slave elements matrix\n");
		exit(1);
	}
	master_els_type = getElementType(master_els); // get element type from element matrices
	slave_els_type  = getElementType(slave_els);
	master = new Boundary(master_els, coordinates, master_els_type);
	slave  = new Boundary( slave_els, coordinates,  slave_els_type);


	if (DEBUG_OUTPUTS)
	{
//		cout << "contact_3d_mex: reading boundaries  ... done\n";
//		cout << "master element type: " << master->get_element_type() << endl;
		cout << "slave  element type: " <<  slave->get_element_type() << endl;
	}
	/// Make slave -> master mapping
	BoundaryMapper boundary_mapper;
	boundary_mapper.set_slave(slave);
	boundary_mapper.set_master(master);
	std::vector<Mapping>  *mapping = new std::vector<Mapping>();
	boundary_mapper.execute(mapping);
	cout << "contact_3d_mex: create mapping (size " << mapping->size() << ") ... done\n";


	FEPrimalBase fe_slave(4);
	FEPrimalBase fe_master(4);

	// digonal matrix D
	std::map<int,std::map<int,double> > d;
	// matrix M
	std::map<int,std::map<int,double> > m;
	// sparse vector SUPPORTS
	std::map<int,std::map<int,double> > supports;
	// three columns sparse matrix NORMALS
	std::map<int,std::map<int,double> > normals;

	Assembler assembler;
	assembler.assemble_d_m(mapping, master, d, m);
	assembler.assemble_supports_normals(slave, supports, normals);

	if (DEBUG_OUTPUTS)
	{
		/// Debug: write slave -> master mapping to Ensight gold file
		std::ostringstream tmp_ostringstream;
		tmp_ostringstream << example_root << problem_name;// << "_" << i;
		std::string tmp_string = tmp_ostringstream.str();
		write_ensight_gold_slave_master_mapping( boundary_mapper, mapping, tmp_string.c_str(), 1);
		write_ensight_gold_normals( boundary_mapper, mapping, tmp_string.c_str(), 1);
		write_mapping( mapping, master, tmp_string.c_str(), 1);
		// Debug: write matrices

	}
	delete mapping;
	/// clear objects at exit
	if (coordinates)  { delete coordinates;	}
	if (master_els)   { delete master_els; 	}
	if (slave_els)    { delete slave_els;	}
	if (master)       { delete master;      }
	if (slave)        { delete slave;       }
    return 0;
}
