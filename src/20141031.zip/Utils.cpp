#include "Utils.h"

BoundingVolume * get_bound_volume(Node **nodes, int node_count, int bounds_count)
{
	Interval *b = new Interval[bounds_count];

	double min_, max_, value;
	for(int i = 0; i < bounds_count; i++) {
		min_ = Element::get_value_of_fn[i](nodes[0]);
		max_ = min_;
		for(int j = 1; j < node_count; j++) {
			value = Element::get_value_of_fn[i](nodes[j]);
			if(value < min_) {
				min_ = value;
			}
			if(value > max_) {
				max_ = value;
			}
		}
		b[i] = Interval(min_, max_);
	}

	BoundingVolume *bounds = new BoundingVolume(b, bounds_count);
	return bounds;
}

MCVec3 transform(MCVec3 p, double *matrix)
{
	MCVec3 result;
	result.x = p.x * matrix[0] + p.y * matrix[3] + p.z * matrix[6];
	result.y = p.x * matrix[1] + p.y * matrix[4] + p.z * matrix[7];
	result.z = p.x * matrix[2] + p.y * matrix[5] + p.z * matrix[8];
	return result;
}

MCVec3 back_transform(MCVec3 p, double *matrix)
{
	MCVec3 result;
	result.x = p.x * matrix[0] + p.y * matrix[1] + p.z * matrix[2];
	result.y = p.x * matrix[3] + p.y * matrix[4] + p.z * matrix[5];
	result.z = p.x * matrix[6] + p.y * matrix[7] + p.z * matrix[8];
	return result;
}

MCVec3 * segment_intersect(MCVec3 p0, MCVec3 p1, MCVec3 q0, MCVec3 q1)
{
	MCVec3 u = p1 - p0;
	MCVec3 v = q1 - q0;
	MCVec3 w = p0 - q0;
	const double e = 0.0001;

	double scale = u.x * v.y - u.y * v.x;
	if(fabs(scale) < e * u.length() * v.length()) { // lines are parallel
		return NULL;
	}

	double s = (w.y * v.x - w.x * v.y) / scale;
	if(s > 1 + e || s < 0 - e) {
		return NULL;
	}

	double t = (w.y * u.x - w.x * u.y) / scale;
	if(t > 1 + e || t < 0 - e) {
		return NULL;
	}

	MCVec3 *intersect = new MCVec3(q0 + v * t);
	return intersect;
}

MCVec3 * line_intersect(MCVec3 p0, MCVec3 p1, MCVec3 q0, MCVec3 q1)
{
	MCVec3 u = p1 - p0;
	MCVec3 v = q1 - q0;
	MCVec3 w = p0 - q0;
	const double e = 0.0001;

	double scale = u.x * v.y - u.y * v.x;
	if(fabs(scale) < e * u.length() * v.length()) { // lines are parallel
		return NULL;
	}

	double t = (w.y * u.x - w.x * u.y) / scale;

	MCVec3 *intersect = new MCVec3(q0 + v * t);
	return intersect;
}

MCVec3 * line_plane_intersect(MCVec3 p0, MCVec3 p1, MCVec3 v0, MCVec3 v1, MCVec3 v2)
{
	double e = 0.001;
	MCVec3 u = v1 - v0;
	MCVec3 v = v2 - v0;
	MCVec3 p = p1 - p0;
	MCVec3 n = cross_prod(u, v);

	double s = dot_prod(n, p);
	if(fabs(s) < e) {
		//TODO: test if line is in plane
		return NULL;
	}

	double t = dot_prod(n, (v0 - p0)) / s;
	MCVec3 *intersect = new MCVec3(p0 + p * t);
	return intersect;
}

MCVec3 get_barymetric(MCVec3 u, MCVec3 v, MCVec3 w)
{
	double uv = dot_prod(u, v);
	double wu = dot_prod(w, u);
	double wv = dot_prod(w, v);
	double uu = dot_prod(u, u);
	double vv = dot_prod(v, v);
	double scale = uv * uv - uu * vv;
	double s = (uv * wv - vv * wu) / scale;
	double t = (uv * wu - uu * wv) / scale;
	return MCVec3(1.0 - s - t, s, t);
}

MCVec3 get_reference(MCVec3 u, MCVec3 v, MCVec3 w)
{
	double uv = dot_prod(u, v);
	double wu = dot_prod(w, u);
	double wv = dot_prod(w, v);
	double uu = dot_prod(u, u);
	double vv = dot_prod(v, v);
	double scale = uv * uv - uu * vv;
	double s = (uv * wv - vv * wu) / scale;
	double t = (uv * wu - uu * wv) / scale;
	return MCVec3(s, t, 0.0);
}

Element * find_neighboor_element(Node *n1, Node *n2, int id)
{
	for(int i = 0; i < n1->get_elements_count(); i++) {
		for(int j = 0; j < n2->get_elements_count(); j++) {
			int id1 = n1->get_element(i)->get_id();
			int id2 = n2->get_element(j)->get_id();
			if((id1 != id) && (id1 == id2)) {
				return n2->get_element(j);
			}
		}
	}
	return NULL;
}

void add_incident_elements(
		Element *master,
		Element *slave,
		ElementMap *added,
		double *projection_matrix)
{
	bool add = false;
	int mc = master->get_node_count();

	for(int i = 0; i < mc; i++) {
		MCVec3 p = master->get_node(i)->get_projection();
		if(slave->is_point_inside(p)) {
			add = true;
			Node *n = master->get_node(i);
			for(int j = 0; j < n->get_elements_count(); j++) {
				Element *e = n->get_element(j);
				if(!added->count(e->get_id())) {
					e->project_element_to_plane(projection_matrix);
					added->insert(std::pair<int, Element*>(e->get_id(), e));
					add_incident_elements(e, slave, added, projection_matrix);
				}
			}
		}
	}

 // if some point is inner we can finish
	if(add) {
		return;
	}
	int sc = slave->get_node_count();
	MCVec3 last;
	for (int i = 0; i < mc; i++) {
		MCVec3 p1 = master->get_node(i)->get_projection();
		MCVec3 p2 = master->get_node((i + 1) % mc)->get_projection();
		MCVec3 u = MCVec3(p2 - p1);
		for (int j = 0; j < sc; j++) {
			MCVec3 q2 = slave->get_node(j)->get_projection();
			MCVec3 v = (q2 - p1);
			if (cross_prod(u, v).z <= 0) {
				MCVec3 prev;
				if (j == 0) {
					prev = slave->get_node(sc - 1)->get_projection();
				} else {
					prev = slave->get_node(j - 1)->get_projection();
				}
				MCVec3 next = slave->get_node((j + 1) % sc)->get_projection();
				MCVec3 *i1 = segment_intersect(p1, p2, prev, q2);
				MCVec3 *i2 = segment_intersect(p1, p2, q2, next);
				if (i2 == NULL && i1 == NULL) {
					break;
				} else {
					delete i1;
					delete i2;
				}
				Element *e = find_neighboor_element(
						master->get_node(i),
						master->get_node((i + 1) % mc),
						master->get_id());
				if (e == NULL) {
					break;
				}
				if (!added->count(e->get_id())) {
					e->project_element_to_plane(projection_matrix);
					added->insert(std::pair<int, Element*>(e->get_id(), e));
					add_incident_elements(e, slave, added, projection_matrix);
				}
				break;
			}
		}
	}
}

PointList * clip_polygons(Element *master, Element *slave)
{
	MCVec3 last, start;
	int previous, first;
	int nodes = master->get_node_count();
	PointList *clipped = new PointList();
	for(int i = 0; i < slave->get_node_count(); i++) {
		clipped->push_back(slave->get_node(i)->get_projection());
	}
	PointList::iterator it;

	for(int i = 0; i < nodes; i++) {
		MCVec3 p2 = master->get_node(i)->get_projection();
		MCVec3 p1 = master->get_node((i + 1) % nodes)->get_projection();
		MCVec3 u = MCVec3(p2 - p1);

		previous = -1;
		first = -1;
		for(it = clipped->begin(); it != clipped->end(); it++) {
			if(previous == -1) {
				start = (*it);
			}

			MCVec3 q2 = (*it);
			MCVec3 v = MCVec3(q2 - p1);
			if(cross_prod(u, v).z >= 0) {
				if(previous == 0) {
					MCVec3 *p = line_intersect(p1, p2, last, q2);
					if (p) {
						clipped->insert(it, *p);
						delete p;
					}
				}
				last = (*it);
				previous = 1;
			} else {
				if(previous == 1) {
					MCVec3 *p = line_intersect(p1, p2, last, q2);
					if(p) {
						clipped->insert(it, *p);
						delete p;
					}
				}
				last = (*it);
				clipped->erase(it--);
				previous = 0;
			}
			if(first == -1) {
				first = previous;
			}
		}
		if(previous != first) {
			MCVec3 *p = line_intersect(p1, p2, last, start);
			if (p) {
				clipped->insert(it, *p);
				delete p;
			}
		}
	}
	// remove points that are too close
	if (clipped->size() > 0) {
		double e = 0.000001; // minimal points distance
		MCVec3 l, f;
		it = clipped->begin();
		l = f = *it;
		for (it++; it != clipped->end(); it++) {
			if (((l.x < it->x + e) && (l.x > it->x - e)) && ((l.y < it->y + e) && (l.y > it->y - e))) {
				clipped->erase(it--);
			}
			l = *it;
		}
		if (clipped->size() > 0 && ((l.x < f.x + e) && (l.x > f.x - e)) && ((l.y < f.y + e) && (l.y > f.y - e))) {
			clipped->erase(clipped->begin());
		}
	}
	return clipped;
}


bool legalize_edge(MCVec3 pi, MCVec3 pj, MCVec3 pk, MCVec3 pl)
{
	MCVec3 vecij = MCVec3((pj - pi));
	MCVec3 midij = MCVec3(pi + vecij / 2);
	MCVec3 tecij = MCVec3(vecij.y, -vecij.x, vecij.z);

	MCVec3 vecik = MCVec3((pk - pi));
	MCVec3 midik = MCVec3(pi + vecik / 2);
	MCVec3 tecik = MCVec3(vecik.y, -vecik.x, vecik.z);

	MCVec3 *center = line_intersect(midij, midij + tecij, midik, midik + tecik);

	double rr = ((*center) - pi).length();
	if(rr <= ((*center) - pl).length()) {
		return true;
	} else {
		return false;
	}
}

void legalize_edge(TDescription *t1, TDescription *t2, int side)
{
	MCVec3 vecij = MCVec3((t1->p[1] - t1->p[0]));
	MCVec3 midij = MCVec3(t1->p[0] + vecij / 2);
	MCVec3 tecij = MCVec3(vecij.y, -vecij.x, vecij.z);

	MCVec3 vecik = MCVec3((t1->p[2] - t1->p[0]));
	MCVec3 midik = MCVec3(t1->p[0] + vecik / 2);
	MCVec3 tecik = MCVec3(vecik.y, -vecik.x, vecik.z);

	MCVec3 *center = line_intersect(midij, midij + tecij, midik, midik + tecik);

	double rr;
	if(center) {
		rr = ((*center) - t1->p[0]).length();
	}
	if(center && rr > ((*center) - t2->p[t1->t[side]->first]).length()) {
		int idx2 = t1->t[side]->first;
		int idx1 = t2->t[idx2]->first;
		t2->p[(idx2 + 2) % 3] = t1->p[idx1];
		t1->p[(idx1 + 2) % 3] = t2->p[idx2];
		TDescription *prev1 = NULL;
		TDescription *prev2 = NULL;
		if(t1->t[(idx1 + 1) % 3] != NULL) {
			prev1 = t1->t[(idx1 + 1) % 3]->second;
			prev1->t[t1->t[(idx1 + 1) % 3]->first]->second = t2;
		}
		if (t1->t[(idx1 + 2) % 3] != NULL) {
			prev2 = t1->t[(idx1 + 2) % 3]->second;
			prev2->t[t1->t[(idx1 + 2) % 3]->first]->second = t1;
		}
		delete t2->t[idx2];
		delete t1->t[idx1];
		t2->t[idx2] = t1->t[(idx1 + 1) % 3];
		t1->t[idx1] = t2->t[(idx2 + 1) % 3];
		t2->t[(idx2 + 1) % 3] = new std::pair<int, TDescription*>((idx1 + 1) % 3, t1);
		t1->t[(idx1 + 1) % 3] = new std::pair<int, TDescription*>((idx2 + 1) % 3, t2);

		if(prev1 != NULL) {
			legalize_edge(prev1, t2, t2->t[idx2]->first);
		}
		if(prev2 != NULL) {
			legalize_edge(prev2, t1, t1->t[(idx1 + 2) % 3]->first);
		}
	}
	if(center) {
		delete center;
	}
}

std::vector<TDescription*> triangulate(PointList* polygon)
{
	//mexPrintf("triangulation.....(");
	std::vector<TDescription*> triangles = std::vector<TDescription*>();

	PointList::iterator it;
	/*it = polygon->begin();
	while (it != polygon->end()) {
		mexPrintf("[%f, %f] ", it->x, it->y);
		it++;
	}
	mexPrintf("---> ");*/

	it = polygon->begin();
	TDescription *t = new TDescription();
	t->p[0] = *it++;
	t->p[1] = *it++;
	t->p[2] = *it++;
	triangles.push_back(t);

	int i = 0;
	while (it != polygon->end()) {
		//mexPrintf("[%f, %f] ", it->x, it->y);
		TDescription *t = new TDescription();
		t->p[0] = triangles[i]->p[0];
		t->p[1] = triangles[i]->p[2];
		t->p[2] = *it++;
		triangles[i]->t[1] = new std::pair<int, TDescription*>(2, t);
		t->t[2] = new std::pair<int, TDescription*>(1, triangles[i]);
		triangles.push_back(t);
		i++;
		legalize_edge(triangles[i - 1], triangles[i], 1);
	}

	return triangles;

}

void dense_matrix_inverse(double * a, int n)
{
	LAPACKINT nn = n;
	LAPACKINT *ipiv = new LAPACKINT[nn+1];
	LAPACKINT lwork = nn*nn;
	double *work = new double[lwork];
	LAPACKINT info;

	dgetrf_(&nn,&nn,a,&nn,ipiv,&info);
	dgetri_(&nn,a,&nn,ipiv,work,&lwork,&info);

	delete ipiv;
	delete work;
}

void dense_matrix_multiply(double * a, double * b, double * c, int m, int n, int o)
{
	const char trans = 'N';
	double alpha = 1.0;
	double beta  = 0.0;

	if (o==0) o = m;
	if (n==0) n = o;

	dgemm_(&trans, &trans, &m, &o, &n, &alpha, a, &m, b, &n, &beta, c, &m);
}

void dense_matrix_solve(double * a, double * b, int n, int o)
{
	LAPACKINT nn = n;
	LAPACKINT oo = o;
	LAPACKINT *ipiv = new LAPACKINT[nn+1];
	LAPACKINT info;

	dgesv_(&nn, &oo, a, &nn, ipiv, b, &nn, &info);
	delete ipiv;
}

void dense_matrix_transpose(double * a, int m, int n)
{
	for (int i=0; i < m; i++)
	{
		for (int j=i+1; j < n; j++)
		{
			double tmp = a[j*m+i];
			a[j*m+i] = a[i*n+j];
			a[i*n+j] = tmp;
		}
	}
}

void mex_print_full_matrix(double * a, int m, int n)
{
//	for (int i = 0; i < m; i++)
//	{
//		for (int j = 0; j < n; j++)
//		{
//			mexPrintf(" %.3f", a[j*m+i]);
//		}
//		mexPrintf("\n");
//	}
}

/* begin: Functions **********************************************/

int getElementType(DenseMatrix<int> *els)
{
	if((*els)[ 8*els->get_columns()+0]==0) return M_ELEMENT_LINE2;
	if((*els)[ 9*els->get_columns()+0]==0) return M_ELEMENT_LINE3;
	if((*els)[10*els->get_columns()+0]==0 && (*els)[ 8*els->get_columns()+0]==(*els)[ 9*els->get_columns()+0]) return M_ELEMENT_TRIA3;
	if((*els)[10*els->get_columns()+0]==0) return M_ELEMENT_QUAD4;
	if((*els)[13*els->get_columns()+0] >0 && (*els)[ 8*els->get_columns()+0]==(*els)[ 9*els->get_columns()+0]) return M_ELEMENT_TRIA6;
	if((*els)[13*els->get_columns()+0] >0) return M_ELEMENT_QUAD8;

	return -1;
}

void write_mapping(std::vector<Mapping> *mapping, Boundary * master, const char *fname, int ii)
{
	std::ostringstream tmp_ostringstream;
	time_t rawtime;
	struct tm * timeinfo;
	tmp_ostringstream << fname << "/mapping_" << ii << ".txt";
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	std::ofstream out_file;
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "Mapping description (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n\n";
		out_file << std::setiosflags(std::ios::right) << std::setprecision(5);
		for (unsigned int i = 0; i < mapping->size(); i++)
		{
			out_file << "S:  " << mapping->at(i).get_element_slave()->get_id() << "   [";
			for (int j = 0; j < mapping->at(i).get_element_slave()->get_node_count(); j++)
			{
				out_file << "  " << std::setw(4) << mapping->at(i).get_element_slave()->get_node(j)->get_id();
			}
			out_file << " ] -----------------------------------\n";
			const std::map<int, std::vector<SegmentTriangle> > & segments_for_master = mapping->at(i).get_segments_for_master();
			std::map<int, std::vector<SegmentTriangle> >::const_iterator it_end = segments_for_master.end();
			for (std::map<int, std::vector<SegmentTriangle> >::const_iterator it = segments_for_master.begin(); it != it_end; ++it)
			{
				out_file << "  M:  " << it->first << "  [";
				for (int j = 0; j < master->get_element(it->first)->get_node_count(); j++)
				{
					out_file << "  " << std::setw(4) << master->get_element(it->first)->get_node(j)->get_id();
				}
				out_file << " ]\n";
				std::vector<SegmentTriangle>::const_iterator seg_it_end = it->second.end();
				int counter=0;
				for (std::vector<SegmentTriangle>::const_iterator seg_it = it->second.begin(); seg_it != seg_it_end; ++seg_it)
				{
					out_file << "    Tri:  " << ++counter << "      s[ ("
							<< std::setw(7) << seg_it->s[0].x << ", "
							<< std::setw(7) << seg_it->s[0].y << "), ("
							<< std::setw(7) << seg_it->s[1].x << ", "
							<< std::setw(7) << seg_it->s[1].y << "), ("
							<< std::setw(7) << seg_it->s[2].x << ", "
							<< std::setw(7) << seg_it->s[2].y << ")],   m[ ("
							<< std::setw(7) << seg_it->m[0].x << ", "
							<< std::setw(7) << seg_it->m[0].y << "), ("
							<< std::setw(7) << seg_it->m[1].x << ", "
							<< std::setw(7) << seg_it->m[1].y << "), ("
							<< std::setw(7) << seg_it->m[2].x << ", "
							<< std::setw(7) << seg_it->m[2].y << ")]\n";
//					out_file << "    Tri:  " << ++counter << "      s[ ("
//							<< ((seg_it->s[0].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[0].x) << ", "
//							<< ((seg_it->s[0].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[0].y) << "), ("
//							<< ((seg_it->s[1].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[1].x) << ", "
//							<< ((seg_it->s[1].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[1].y) << "), ("
//							<< ((seg_it->s[2].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[2].x) << ", "
//							<< ((seg_it->s[2].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->s[2].y) << ")],   m[ ("
//							<< ((seg_it->m[0].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[0].x) << ", "
//							<< ((seg_it->m[0].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[0].y) << "), ("
//							<< ((seg_it->m[1].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[1].x) << ", "
//							<< ((seg_it->m[1].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[1].y) << "), ("
//							<< ((seg_it->m[2].x >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[2].x) << ", "
//							<< ((seg_it->m[2].y >= 0)? " ": "-") << std::setw(7) << fabs(seg_it->m[2].y) << ")]\n";
				}
			}
		}
	}
}

void write_ensight_gold_slave_master_mapping(
		BoundaryMapper &project, std::vector<Mapping> *mappings_ptr, const char *fname, int ii)
{
	std::ostringstream tmp_ostringstream;
	time_t rawtime;
	struct tm * timeinfo;
	int part_counter = 1;
	int node_counter = 1;
	int element_counter = 1;
    int tmp_int;
	/* ENSIGHT .case FILE */
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses_output_mapping_" << ii << ".case";
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	std::ofstream out_file;
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "# Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
		out_file << "# EnSight Gold Model\n\n";
		out_file << "FORMAT\n";
		out_file << "type:                   ensight gold\n\n";
		out_file << "GEOMETRY\n";
		out_file << "model:                  contact_3d_mex_withoutclasses_output_mapping_" << "000" << ".geo\n\n";
		out_file.close();
	}
	/* ENSIGHT .geo FILE */
	tmp_ostringstream.str("");
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses_output_mapping_" << "000" << ".geo";
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
		out_file << "Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
		out_file << "node id given\n";
		out_file << "element id given\n";
		out_file << "extents\n";
		out_file << std::setiosflags(std::ios::right | std::ios::scientific) << std::setprecision(5);
		BoundingVolume * tmp_interval = project.get_master_bvt()->get_item();
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).end << "\n";
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).end << "\n";
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).end << "\n";
		/* SLAVE */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		out_file << "slave\n";
		project.get_slave()->write_ensight_gold(&out_file, node_counter, element_counter);
		/* MASTER */
		out_file << "part\n";
		out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		out_file << "master\n";
		project.get_master()->write_ensight_gold(&out_file, node_counter, element_counter);
		/* MAPPING */
		tmp_int = mappings_ptr->size();
		for (int i=0; i<tmp_int; i++)
		{
			if (mappings_ptr->at(i).get_element_coverage_area_ratio() < MIN_SLAVE_COVER_RATIO) continue;
			out_file << "part\n";
			out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
			out_file << "mapping[" << i << "] (" << mappings_ptr->at(i).get_element_slave()->get_id() << ")\n";
			mappings_ptr->at(i).write_ensight_gold(&out_file, node_counter, element_counter);
		}
	}
	out_file.close();
}

void write_ensight_gold_normals(BoundaryMapper &project, std::vector<Mapping> *mappings_ptr, const char *fname, int ii)
{
	std::ostringstream tmp_ostringstream;
	time_t rawtime;
	struct tm * timeinfo;
	int part_counter = 1;
	int node_counter = 1;
	int element_counter = 1;
	/* ENSIGHT .case FILE */
	std::ofstream out_file;
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses_output_slave_master_" << ii << ".case";
	time (&rawtime);
	timeinfo = localtime(&rawtime);
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "# Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
		out_file << "# EnSight Gold Model\n\n";
		out_file << "FORMAT\n";
		out_file << "type:                   ensight gold\n\n";
		out_file << "GEOMETRY\n";
		out_file << "model:                  contact_3d_mex_withoutclasses_output_slave_master_" << ii << ".geo\n\n";
		out_file << "VARIABLES\n";
		out_file << "vector per node: 1 1 Normals contact_3d_mex_withoutclasses__normals_" << ii << ".Nvec\n";
		out_file << "scalar per node: 1 1 Supports contact_3d_mex_withoutclasses__supports_" << ii << ".Nsca\n";
		out_file.close();
	}
	/* ENSIGHT .geo FILE */
	tmp_ostringstream.str("");
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses_output_slave_master_" << ii << ".geo";
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
		out_file << "Date (" << timeinfo->tm_mday << "-" << 1+timeinfo->tm_mon << "-" << 1900+timeinfo->tm_year << ")\n";
		out_file << "node id given\n";
		out_file << "element id given\n";
		out_file << "extents\n";
		out_file << std::setiosflags(std::ios::right | std::ios::scientific) << std::setprecision(5);
		BoundingVolume * tmp_interval = project.get_master_bvt()->get_item();
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(0).end << "\n";
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(1).end << "\n";
		out_file << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).start
				 << std::setw(ENSIGHT_GOLD_DOUBLE_WIDTH) << tmp_interval->get_bound(4).end << "\n";
		/* SLAVE */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		out_file << "slave\n";
		project.get_slave()->write_ensight_gold(&out_file, node_counter, element_counter);
		/* MASTER */
		out_file << "part\n";
		out_file << std::setw( ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		out_file << "master\n";
		project.get_master()->write_ensight_gold(&out_file, node_counter, element_counter);
	}
	out_file.close();
	/* ENSIGHT contact_3d_mex_withoutclasses__normals.Nvec FILE */
	tmp_ostringstream.str("");
	part_counter = 1;
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses__normals_" << ii << ".Nvec";
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
		/* SLAVE */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		project.get_slave()->write_normals_ensight_gold(&out_file);
		/* MASTER */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		project.get_master()->write_normals_ensight_gold(&out_file);
	}
	out_file.close();
	/* ENSIGHT contact_3d_mex_withoutclasses__supports.Nsca FILE */
	tmp_ostringstream.str("");
	part_counter = 1;
	tmp_ostringstream << fname << "/contact_3d_mex_withoutclasses__supports_" << ii << ".Nsca";
	out_file.open(tmp_ostringstream.str().c_str());
	if (out_file.is_open())
	{
		out_file << "This is the description of the EnSight Gold geometry, MODEL:\n";
		/* SLAVE */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		project.get_slave()->write_supports_ensight_gold(&out_file);
		/* MASTER */
		out_file << "part\n";
		out_file << std::setw(ENSIGHT_GOLD_INT_WIDTH) << part_counter++ << "\n";
		project.get_master()->write_supports_ensight_gold(&out_file);
	}
	out_file.close();
}

/* end:   Functions **********************************************/
