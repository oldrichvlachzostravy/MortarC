#ifndef BOUNDINGVOLUMETREE_H_
#define BOUNDINGVOLUMETREE_H_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "SystemIncludes.h"
#include "Element.h"
#include "Node.h"

#define BOUNDING_VOLUME_2D 0
#define BOUNDING_VOLUME_3D 1

#define EPSILON 0.01

class Element;
class Node;

/**
 * Structure that represents the interval on the real axis (\f$ I=\langle a,b \rangle=\{x\in\mathbb{R}|\, a \leq x \leq b\}\f$)
 */
struct Interval
{
	    /**
	     * default constructor \f$ a=b=0 \f$
	     */
		Interval(): start(0), end(0) { };
		/**
		 * constructor
		 * @param s = center
		 * @param e = (a+b)/2
		 */
		Interval(double s, double e): start(s - EPSILON), end(e + EPSILON) {
			assert(start < end);
		};

		double start;
		double end;
        /**
         * @return true if this is the subset of interval, \f$ this \subseteq interval \f$, false otherwise
         * @param interval given interval
         */
		bool is_overlapped(Interval interval) {
			if(interval.start > end) return false;
			if(interval.end < start) return false;
			return true;
		}

		/**
		 * @return the size of this
		 */
		double get_interval_size() { return end - start; }
};

/**
 * The 3D \f$ k--DOP\f$
 */
class BoundingVolume
{
	public:
		BoundingVolume(Interval*, int);
		~BoundingVolume();

		Interval * get_bounds();
		Interval get_bound(int);
		double get_biggest_interval();
		int get_biggest_interval_index();
		void set_element(Element*);
		Element * get_element();

		bool is_overlapped(BoundingVolume*);

	private:
		int bounds_count;
		Interval *bounds;
		Element *element;
};

class BoundingVolumeTree
{
	public:
		BoundingVolumeTree(BoundingVolume*);
		~BoundingVolumeTree();

		BoundingVolume * get_item();
		void set_leaf(BoundingVolume*, int);
		BoundingVolumeTree * get_leaf(int);

		Element * find_closest_element(BoundingVolume*);

	protected:
		BoundingVolume *item;
		BoundingVolumeTree **leaf;

};

#endif /* BOUNDINGVOLUMETREE_H_ */
