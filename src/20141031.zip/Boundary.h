#ifndef BOUNDARY_H_
#define BOUNDARY_H_

#include <cstring>
#include <vector>
#include <map>
#include <iostream>
#include <iomanip>
#include <fstream>

class Boundary;

#include "SystemIncludes.h"
#include "Element.h"
#include "Node.h"
#include "BoundingVolumeTree.h"
#include "DenseMatrix.h"
#include "Utils.h"
#include "FEPrimalBase.h"

// only temporalily
//#include "mex.h"


class Mapping;
class Interval;
class BoundingVolume;
class BoundingVolumeTree;

#define NORMAL_LENGHT 30
#ifndef ENSIGHT_GOLD_DOUBLE_WIDTH
#define ENSIGHT_GOLD_DOUBLE_WIDTH 12
#endif
#ifndef ENSIGHT_GOLD_INT_WIDTH
#define ENSIGHT_GOLD_INT_WIDTH 10
#endif

/**
 * The Boundary class represents the interface to the boundary of FEM mesh
 *
 *  @author Ondřej Meca
 */
class Boundary
{
	public:
		Boundary( DenseMatrix<int>*, DenseMatrix<double>*, int);
		~Boundary();

		void calculate_normals_and_supports();
		BoundingVolumeTree * compute_bounding_volume_tree();
		void find_closest_elements( BoundingVolumeTree*);
		void map_elements(std::vector<Mapping> *);
		Element * get_element(int);
		int get_elements_size();
		int get_element_type();
		int write_ensight_gold( std::ofstream *, int&, int&);
		int write_normals_ensight_gold( std::ofstream *);
		int write_supports_ensight_gold( std::ofstream *);
		std::vector<Element*>::iterator get_element_iterator_begin();
		std::vector<Element*>::iterator get_element_iterator_end();

	protected:
		Node* get_unique_node_or_create_new( int, DenseMatrix<double>*);

		std::vector<Element* > elements;
		std::map<int, Node* > nodes;
		int elements_type;

	private:
		Element *** sort_elements();
		Interval * get_elements_bounds( Element***, uint);
		void divide_bound_volume( BoundingVolumeTree*, Element***, int);
		Element **** split_elements( Element ***, int, int);
		BoundingVolume * create_normal_bounds( Node*, MCVec3, double);
};

#endif /* BOUNDARY_H_ */
